import React from 'react';

const Body = () => {
  return (
    <main>
      <p>Body</p>
    </main>
  );
};

export default Body;
